package com.ai.resume_builder;

public @interface SpringBootTest {
}
