package com.ai.resume_builder;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@com.ai.resume_builder.SpringBootTest
class ResumeBuilderApplicationTests {

	@Test
	void contextLoads() {
	}

}
