package com.ai.resume_builder.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "ats_results")
public class AtsHistory {

    @Id
    private String id;

    private String jobDescription;
    private String resumeText;
    private int score;

    // getters and setters
}