//package com.ai.resume_builder.controller;//package com.ai.resume_builder.controller;
//
//import com.ai.resume_builder.model.Resume;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.data.mongodb.core.MongoTemplate;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.*;
//
//import com.itextpdf.kernel.pdf.PdfWriter;
//import com.itextpdf.kernel.pdf.PdfDocument;
//import com.itextpdf.layout.Document;
//import com.itextpdf.layout.element.Paragraph;
//
//import java.io.ByteArrayOutputStream;
//
//@RestController
//@RequestMapping("/api")
//@CrossOrigin(origins = "*")
//public class ResumeController {
//
//    @Autowired
//    private MongoTemplate mongoTemplate;
//
//    // ✅ PDF GENERATE API
//    @GetMapping("/pdf/{id}")
//    public ResponseEntity<byte[]> pdf(@PathVariable String id) throws Exception {
//
//        // MongoDB से data fetch
//        Resume r = mongoTemplate.findById(id, Resume.class);
//
//        // PDF create
//        ByteArrayOutputStream out = new ByteArrayOutputStream();
//
//        PdfWriter writer = new PdfWriter(out);
//        PdfDocument pdfDoc = new PdfDocument(writer);
//        Document doc = new Document(pdfDoc);
//
//        // content add
//        doc.add(new Paragraph("RESUME"));
//        doc.add(new Paragraph("Name: " + r.getName()));
//        doc.add(new Paragraph("Email: " + r.getEmail()));
//        doc.add(new Paragraph("Skills: " + String.join(", ", r.getSkills())));
//
//        doc.close();
//
//        return ResponseEntity.ok()
//                .header("Content-Disposition", "attachment; filename=resume.pdf")
//                .body(out.toByteArray());
//    }
//}


//import com.ai.resume_builder.model.Resume;
//import com.ai.resume_builder.repository.ResumeRepository;
//import com.ai.resume_builder.service.GeminiService;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.web.bind.annotation.*;
//
//@RestController
//@RequestMapping("/api")
//@CrossOrigin(origins = "*")
//public class ResumeController {
//
//    @Autowired
//    private ResumeRepository repo;
//
//    @Autowired
//    private GeminiService gemini;
//
//    @PostMapping("/resume")
//    public Resume create(@RequestBody Resume resume){
//        return repo.save(resume);
//    }
//
//    @PostMapping("/cover")
//    public String cover(@RequestBody Resume resume) throws Exception {
//        return gemini.generateCoverLetter(resume.getName());
//    }
//
//
//
//}



//package com.ai.resume_builder.controller;

//import com.ai.resume_builder.model.Resume;
//import com.ai.resume_builder.repository.ResumeRepository;
//import com.ai.resume_builder.service.AtsService;
//import com.ai.resume_builder.service.GeminiService;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.data.mongodb.core.MongoOperations;
//import org.springframework.web.bind.annotation.*;
//
//import java.util.List;
//
//@RestController
//@RequestMapping("/api")
//@CrossOrigin("*")
//public class ResumeController {
//
//    @Autowired
//    private ResumeRepository repo;
//
//    @Autowired
//    private AtsService ats;
//
//    @Autowired
//    private GeminiService gemini;
//
//    @PostMapping("/resume")
//    public Resume save(@RequestBody Resume resume){
//        return repo.save(resume);
//    }
//
//    @GetMapping("/resume")
//    public List<Resume> getAll(){
//        return repo.findAll();
//    }
//
//    @PostMapping("/ats")
//    public int ats(@RequestBody Resume resume){
//        return ats.calculate(resume);
//    }
//
//    @PostMapping("/cover")
//    public String cover(@RequestBody Resume resume) throws Exception {
//        return gemini.generateCoverLetter(resume.getName());
//    }
//}





//import com.ai.resume_builder.model.Resume;
//import com.ai.resume_builder.repository.ResumeRepository;
//import com.ai.resume_builder.service.AtsService;
//import com.ai.resume_builder.service.GeminiService;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.web.bind.annotation.*;
//
//import java.util.List;
//
//@RestController
//@RequestMapping("/api")
//@CrossOrigin("*")
//public class ResumeController {
//
//    @Autowired
//    private ResumeRepository repo;
//
//    @Autowired
//    private AtsService ats;
//
//    @Autowired
//    private GeminiService gemini;
//
//    // ✅ SAVE RESUME
//    @PostMapping("/resume")
//    public Resume save(@RequestBody Resume resume){
//        return repo.save(resume);
//    }
//
//    // ✅ GET ALL RESUME
//    @GetMapping("/resume")
//    public List<Resume> getAll(){
//        return repo.findAll();
//    }
//
//    // ✅ ATS SCORE
//    @PostMapping("/ats")
//    public int getATS(@RequestBody Resume resume){
//        return ats.calculate(resume);
//    }
//
//    // ✅ COVER LETTER
//    @PostMapping("/cover")
//    public String getCover(@RequestBody Resume resume) throws Exception {
//        return gemini.generateCoverLetter(resume.getName());
//    }
//
//    // ✅ TEST API (IMPORTANT)
//    @GetMapping("/")
//    public String test(){
//        return "API Working ✅";
//    }
//}

//package com.ai.resume_builder.controller;
//
//import com.ai.resume_builder.service.SkillGapService;
//import com.ai.resume_builder.model.Resume;
//import com.ai.resume_builder.repository.ResumeRepository;
//import com.ai.resume_builder.service.AtsService;
//import com.ai.resume_builder.service.GeminiService;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.data.mongodb.core.MongoOperations;
//import org.springframework.web.bind.annotation.*;
//
//import java.util.List;
//import java.util.Map;
//
//@RestController
//@RequestMapping("/api/resume")   // 🔥 better base path
//@CrossOrigin("*")
//public class ResumeController {
//
//    @Autowired
//    private ResumeRepository repo;
//
//
//    @Autowired
//    private SkillGapService skillGapService;
//
//
//    @Autowired
//    private AtsService ats;
//
//    @Autowired
//    private GeminiService gemini;
//
//    // ✅ TEST API
//    @GetMapping("/test")
//    public String test(){
//        return "API Working ✅";
//    }
//
//    // ✅ CREATE RESUME
//    @PostMapping("/create")
//    public Resume create(@RequestBody Resume resume){
//        return repo.save(resume);
//    }
//
//    // ✅ GET ALL RESUME
//    @GetMapping("/all")
//    public List<Resume> getAll(){
//        return repo.findAll();
//    }
//
//    // ✅ GET BY ID
//    @GetMapping("/{id}")
//    public Resume getById(@PathVariable String id){
//        return repo.findById(id).orElse(null);
//    }
//
//    // ✅ UPDATE
//    @PutMapping("/update/{id}")
//    public Resume update(@PathVariable String id, @RequestBody Resume resume){
//        resume.setId(id);
//        return repo.save(resume);
//    }
//
//    // ✅ DELETE
//    @DeleteMapping("/delete/{id}")
//    public String delete(@PathVariable String id){
//        repo.deleteById(id);
//        return "Deleted Successfully";
//    }
//
//    // ✅ ATS SCORE
//    @PostMapping("/ats")
//    public int getATS(@RequestBody Resume resume){
//        return ats.calculate(resume);
//    }
//
//    // ✅ COVER LETTER
//    @PostMapping("/cover")
//    public String getCover(@RequestBody Resume resume) throws Exception {
//        return gemini.generateCoverLetter(resume.getName());
//    }
//
//    @PostMapping("/skill-gap")
//    public Map<String, Object> skillGap(@RequestBody Resume resume){
//        return skillGapService.analyze(resume.getSkills());
//    }
//
//
//
//    @PostMapping("/api/resume")
//    public Resume save(@RequestBody Resume resume){
//        MongoOperations repository = null;
//        return repository.save(resume);
//    }
//
//}







//package com.ai.resume_builder.controller;
//
//import com.ai.resume_builder.model.Resume;
//import com.ai.resume_builder.repository.ResumeRepository;
//import com.ai.resume_builder.service.AtsService;
//import com.ai.resume_builder.service.GeminiService;
//import com.ai.resume_builder.service.SkillGapService;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.web.bind.annotation.*;
//
//import java.util.List;
//import java.util.Map;
//
//@RestController
//@RequestMapping("/api/resume")
//@CrossOrigin("*")
//public class ResumeController {
//
//    @Autowired
//    private ResumeRepository repo;
//
//    @Autowired
//    private SkillGapService skillGapService;
//
//    @Autowired
//    private AtsService ats;
//
//    @Autowired
//    private GeminiService gemini;
//
//    // ================= TEST =================
//    @GetMapping("/test")
//    public String test() {
//        return "API Working ✅";
//    }
//
//    // ================= CREATE RESUME =================
//
//    @PostMapping("/create")
//    public Resume save(@RequestBody Resume resume){
//        return repo.save(resume);
//    }
//
//
//
//
//    // ================= GET ALL =================
//    @GetMapping("/all")
//    public List<Resume> getAll() {
//        return repo.findAll();
//    }
//
//    // ================= GET BY ID =================
//    @GetMapping("/{id}")
//    public Resume getById(@PathVariable String id) {
//        return repo.findById(id).orElse(null);
//    }
//
//    // ================= UPDATE =================
//    @PutMapping("/{id}")
//    public Resume update(@PathVariable String id, @RequestBody Resume resume) {
//        resume.setId(id);
//        return repo.save(resume);
//    }
//
//    // ================= DELETE =================
//    @DeleteMapping("/{id}")
//    public String delete(@PathVariable String id) {
//        repo.deleteById(id);
//        return "Deleted Successfully ✅";
//    }
//
//    // ================= ATS SCORE =================
//    @PostMapping("/ats")
//    public int getATS(@RequestBody Resume resume) {
//        return ats.calculate(resume);
//    }
//
//    // ================= COVER LETTER =================
//    @PostMapping("/cover")
//    public String getCover(@RequestBody Resume resume) throws Exception {
//        return gemini.generateCoverLetter(resume.getName());
//    }
//
//    // ================= SKILL GAP =================
//    @PostMapping("/skill-gap")
//    public Map<String, Object> skillGap(@RequestBody Resume resume) {
//        return (Map<String, Object>) skillGapService.analyze(resume.getSkills());
//    }
//}







//package com.ai.resume_builder.controller;
//
//import com.ai.resume_builder.service.AiResumeService;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.web.bind.annotation.*;
//
//import java.util.Map;
//
//@RestController
//@RequestMapping("/api")
//@CrossOrigin(origins = "*") // 🔥 important for frontend
//public class ResumeController {
//
//    @Autowired
//    private AiResumeService aiService;
//
//    // ✅ AI GENERATE
//    @PostMapping("/generate")
//    public Map<String, Object> generate(@RequestBody Map<String, String> body) {
//        String prompt = body.get("prompt");
//        return aiService.generateResume(prompt);
//    }
//
//    // ✅ SAVE RESUME
//    @PostMapping("/save")
//    public Map<String, Object> save(@RequestBody Map<String, Object> data) {
//        return data; // abhi simple (Mongo later)
//    }
//}





//package com.ai.resume_builder.controller;
//
//import com.ai.resume_builder.model.Resume;
//import com.ai.resume_builder.repository.ResumeRepository;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.web.bind.annotation.*;
//
//@RestController
//@RequestMapping("/api/resume")
//@CrossOrigin("*")
//public class ResumeController {
//
//    @Autowired
//    private ResumeRepository repo;
//
//    // ================= SAVE RESUME =================
//    @PostMapping("/save")
//    public Resume save(@RequestBody Resume resume) {
//        return repo.save(resume);
//    }
//
//    // ================= GET RESUME =================
//    @GetMapping("/{id}")
//    public Resume get(@PathVariable String id) {
//        return repo.findById(id).orElse(null);
//    }
//}





package com.ai.resume_builder.controller;

import com.ai.resume_builder.model.Resume;
import com.ai.resume_builder.repository.ResumeRepository;
import com.ai.resume_builder.service.GeminiService;
import com.ai.resume_builder.service.PdfService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.InputStream;

@RestController
@RequestMapping("/api/resume")
@CrossOrigin("*")
public class ResumeController {

    @Autowired
    private PdfService pdfService;

    @Autowired
    private GeminiService geminiService;

    @Autowired
    private ResumeRepository repository;

    @PostMapping("/analyze")
    public Resume analyzeResume(
            @RequestParam("file") MultipartFile file,
            @RequestParam(value = "job", required = false) String job,
            @RequestParam("type") String type
    ) {

        try {
            InputStream inputStream = file.getInputStream();

            // 1. Extract PDF text
            String resumeText = pdfService.extractText(inputStream);

            System.out.println("RESUME TEXT:\n" + resumeText);

            // 2. AI analysis (Gemini)
            String response = geminiService.getATSAnalysis(resumeText, job, type);

            // 3. Save to DB
            Resume resume = new Resume();
            resume.setFileName(file.getOriginalFilename());
            resume.setResumeText(resumeText);
            resume.setJobDescription(job);
            resume.setAtsResponse(response);

            // TODO: replace with real AI score later
            resume.setAtsScore(85);

            return repository.save(resume);

        } catch (Exception e) {
            throw new RuntimeException("Error analyzing resume: " + e.getMessage());
        }
    }
}
