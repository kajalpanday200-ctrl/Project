package com.ai.resume_builder.model;

import lombok.*;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Document(collection = "resumes")
public class Resume {

    @Id
    private String id;

    private String fileName;
    private String resumeText;
    private String jobDescription;

    private String atsResponse;
    private int atsScore;
}