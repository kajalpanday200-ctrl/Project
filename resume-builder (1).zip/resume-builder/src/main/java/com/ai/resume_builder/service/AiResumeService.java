//package com.ai.resume_builder.service;
//
//import com.fasterxml.jackson.databind.JsonNode;
//import com.fasterxml.jackson.databind.ObjectMapper;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.beans.factory.annotation.Value;
//import org.springframework.http.*;
//import org.springframework.stereotype.Service;
//import org.springframework.web.client.RestTemplate;
//
//import java.util.HashMap;
//import java.util.Map;
//
//@Service
//public class AiResumeService {
//
//    @Autowired
//    private RestTemplate restTemplate;
//
//    @Value("${gemini.api.key}")
//    private String API_KEY;
//
//    public Map generateResume(String prompt) {
//
//        try {
//
//            String aiPrompt = """
//            Extract resume details ONLY from input.
//
//            RULES:
//            - Return ONLY JSON
//            - Do NOT add extra skills
//            - Do NOT add explanation
//            - If not present → keep empty
//
//            FORMAT:
//            {
//              "name": "",
//              "email": "",
//              "phone": "",
//              "summary": "",
//              "skills": [],
//              "education": [],
//              "experience": [],
//              "projects": [],
//              "certificates": [],
//              "achievements": [],
//              "github": "",
//              "linkedin": ""
//            }
//
//            INPUT:
//            """ + prompt;
//
//            String url = "https://generativelanguage.googleapis.com/v1/models/gemini-2.0-flash:generateContent?key=" + API_KEY;
//
//            String body = """
//            {
//              "contents": [
//                {
//                  "parts": [
//                    {
//                      "text": "%s"
//                    }
//                  ]
//                }
//              ]
//            }
//            """.formatted(aiPrompt.replace("\"", "\\\""));
//
//            HttpHeaders headers = new HttpHeaders();
//            headers.setContentType(MediaType.APPLICATION_JSON);
//
//            HttpEntity<String> entity = new HttpEntity<>(body, headers);
//
//            String response = restTemplate.postForObject(url, entity, String.class);
//
//            System.out.println("RAW RESPONSE: " + response);
//
//            ObjectMapper mapper = new ObjectMapper();
//            JsonNode root = mapper.readTree(response);
//
//            JsonNode parts = root.path("candidates").get(0).path("content").path("parts");
//
//            if (parts.isEmpty()) {
//                return errorResponse("AI returned empty response");
//            }
//
//            String text = parts.get(0).path("text").asText();
//
//            System.out.println("AI TEXT: " + text);
//
//            if (text == null || text.isEmpty()) {
//                return errorResponse("Empty AI text");
//            }
//
//            // 🔥 JSON extract fix
//            int start = text.indexOf("{");
//            int end = text.lastIndexOf("}");
//
//            if (start != -1 && end != -1) {
//                text = text.substring(start, end + 1);
//            }
//
//            return mapper.readValue(text, Map.class);
//
//        } catch (Exception e) {
//            e.printStackTrace();
//            return errorResponse(e.getMessage());
//        }
//    }
//
//    private Map<String, Object> errorResponse(String msg) {
//        Map<String, Object> error = new HashMap<>();
//        error.put("error", "AI failed");
//        error.put("message", msg);
//        return error;
//    }
//}





package com.ai.resume_builder.service;

import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class AiResumeService {

    private final RestTemplate restTemplate;

    // 👉 Put your real API key here or in application.properties
    private final String API_KEY = "YOUR_GEMINI_API_KEY";

    private final String API_URL =
            "https://generativelanguage.googleapis.com/v1/models/gemini-1.5-flash:generateContent?key=" + API_KEY;

    public AiResumeService(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    public Map<String, Object> generateResume(String prompt) {

        try {
            // 🔥 Request Body for Gemini
            Map<String, Object> textPart = new HashMap<>();
            textPart.put("text", prompt);

            Map<String, Object> content = new HashMap<>();
            content.put("parts", List.of(textPart));

            Map<String, Object> requestBody = new HashMap<>();
            requestBody.put("contents", List.of(content));

            // 🔥 Headers
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);

            HttpEntity<Map<String, Object>> entity =
                    new HttpEntity<>(requestBody, headers);

            // 🔥 API CALL
            ResponseEntity<String> response =
                    restTemplate.postForEntity(API_URL, entity, String.class);

            // ✔ SUCCESS RESPONSE
            Map<String, Object> result = new HashMap<>();
            result.put("success", true);
            result.put("data", response.getBody());
            result.put("message", "Resume generated successfully");

            return result;

        } catch (Exception e) {

            // ❌ Fallback response (VERY IMPORTANT for demo/project)
            Map<String, Object> fallback = new HashMap<>();
            fallback.put("success", false);
            fallback.put("error", "AI_FAILED");

            fallback.put("data", Map.of(
                    "name", "Demo User",
                    "summary", "AI service temporarily unavailable due to quota limit.",
                    "skills", List.of("Java", "Spring Boot", "MongoDB"),
                    "projects", List.of("Resume Builder AI"),
                    "message", "Fallback response used"
            ));

            fallback.put("message", e.getMessage());

            return fallback;
        }
    }
}