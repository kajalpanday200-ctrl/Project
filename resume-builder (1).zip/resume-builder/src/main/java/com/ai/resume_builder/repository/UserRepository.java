//package com.ai.resume_builder.repository;
//
//import com.ai.resume_builder.model.User;
//import org.springframework.data.mongodb.repository.MongoRepository;
//
//import java.util.Optional;
//
//public interface UserRepository extends MongoRepository<User, String> {
//
//    Optional<User> findByEmail(String email);   // ✅ MUST
//}


//package com.ai.resume_builder.repository;
//
//import com.ai.resume_builder.model.User;
//import org.springframework.data.mongodb.repository.MongoRepository;
//
//import java.util.Optional;
//
//public interface UserRepository extends MongoRepository<User, String> {
//
//    Optional<User> findByEmail(String email);
//}


//package com.ai.resume_builder.repository;
//
//import com.ai.resume_builder.model.UserData;
//import org.springframework.data.mongodb.repository.MongoRepository;
//
//public interface UserDataRepository extends MongoRepository<UserData, String> {
//}

package com.ai.resume_builder.repository;

import com.ai.resume_builder.model.User;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.Optional;

public interface UserRepository extends MongoRepository<User, String> {
    Optional<User> findByEmail(String email);
}