//package com.ai.resume_builder.model;
//import lombok.Data;
//import org.springframework.data.annotation.Id;
//import org.springframework.data.mongodb.core.mapping.Document;
//
//import java.util.List;
//
//@Data
//@Document(collection="jobs")
//public class Job {
//
//    @Id
//    private String id;
//
//    private String title;
//    private List<String> skills;
//    private int minExp;
//    private String education;
//}



package com.ai.resume_builder.model;

import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.List;

@Data
@Document(collection = "jobs")
public class Job {

    @Id
    private String id;

    private String title;
    private List<String> skills;
    private int minExp;
    private String education;
}