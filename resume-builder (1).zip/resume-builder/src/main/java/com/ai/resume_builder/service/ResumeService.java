//package com.ai.resume_builder.service;
//
//import com.ai.resume_builder.model.UserData;
//import org.springframework.stereotype.Service;
//
//@Service
//public class ResumeService {
//
//    public String generateResume(UserData data){
//        return "Resume for " + data.getName();
//    }
//}


package com.ai.resume_builder.service;

import com.ai.resume_builder.model.Resume;
import com.ai.resume_builder.repository.ResumeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ResumeService {

    @Autowired
    private ResumeRepository repo;

    public Resume save(Resume resume){
        return repo.save(resume);
    }

    public List<Resume> getAll(){
        return repo.findAll();
    }

    public Resume getById(String id){
        return repo.findById(id).orElse(null);
    }

    public void delete(String id){
        repo.deleteById(id);
    }
}