////package com.ai.resume_builder.controller;
////
////
////import com.ai.resume_builder.dto.AtsRequest;
////import com.ai.resume_builder.model.AtsResponse;
////import com.ai.resume_builder.service.AtsService;
////import org.springframework.beans.factory.annotation.Autowired;
////import org.springframework.web.bind.annotation.PostMapping;
////import org.springframework.web.bind.annotation.RequestBody;
////import org.springframework.web.bind.annotation.RequestMapping;
////import org.springframework.web.bind.annotation.RestController;
////
////@RestController
////@RequestMapping("/api/ats")
////public class AtsScoreController {
////
////    @Autowired
////    private AtsService atsService;
////
////    @PostMapping("/score")
////    public AtsResponse getScore(@RequestBody AtsRequest request) {
////        return atsService.calculateScore(request);
////    }
////}
//
//
//
//
////package com.ai.resume_builder.controller;
////
////
////import com.ai.resume_builder.service.AtsService;
////import com.ai.resume_builder.service.PdfService;
////import org.springframework.beans.factory.annotation.Autowired;
////import org.springframework.web.bind.annotation.PostMapping;
////import org.springframework.web.bind.annotation.RequestMapping;
////import org.springframework.web.bind.annotation.RequestParam;
////import org.springframework.web.bind.annotation.RestController;
////import org.springframework.web.multipart.MultipartFile;
////
////@RestController
////@RequestMapping("/api/ats")
////public class AtsScoreController<AtsResponse> {
////
////    @Autowired
////    private PdfService pdfService;
////
////    @Autowired
////    private AtsService atsService;
////
////    @PostMapping("/analyze")
////    public AtsResponse analyze(
////            @RequestParam("file") MultipartFile file,
////            @RequestParam("jobDesc") String jobDesc
////    ) {
////        try {
////            String resumeText = pdfService.extractText(file.getInputStream());
////            return (AtsResponse) atsService.calculateScore(resumeText, jobDesc);
////        } catch (Exception e) {
////            throw new RuntimeException(e);
////        }
////    }
////}
//
////package com.ai.resume_builder.controller;
////
////import com.ai.resume_builder.service.AtsService;
////import com.ai.resume_builder.service.PdfService;
////import org.springframework.beans.factory.annotation.Autowired;
////import org.springframework.web.bind.annotation.*;
////import org.springframework.web.multipart.MultipartFile;
////
////import java.util.Map;
////
////@RestController
////@RequestMapping("/api/ats")
////@CrossOrigin("*")
////public class AtsController {
////
////    @Autowired
////    private PdfService pdfService;
////
////    @Autowired
////    private AtsService atsService;
//
////    @PostMapping("/analyze")
////    public AtsResponse analyze(
////            @RequestParam("file") MultipartFile file,
////            @RequestParam("jobDesc") String jobDesc
////    ) {
////        try {
////            String resumeText = pdfService.extractText(file.getInputStream());
////            return atsService.calculateScore(resumeText, jobDesc);
////        } catch (Exception e) {
////            throw new RuntimeException(e);
////        }
////    }
////}
//
//
////    @PostMapping("/analyze")
////    public Object analyze(
////            @RequestParam("file") MultipartFile file,
////            @RequestParam("jobDesc") String jobDesc
////    ) {
////        try {
////            System.out.println("📄 File: " + file.getOriginalFilename());
////            System.out.println("📝 JD: " + jobDesc);
////
////            String resumeText = pdfService.extractText(file.getInputStream());
////
////            System.out.println("📄 Extracted Text: " + resumeText);
////
////            return atsService.calculateScore(resumeText, jobDesc);
////
////        } catch (Exception e) {
////            e.printStackTrace(); // 🔥 important
////            return Map.of(
////                    "error", e.getMessage()
////            );
////
////
////
////
////        }}}
//
//
//
//
////package com.ai.resume_builder.controller;
////import com.ai.resume_builder.service.AtsService;
////import com.ai.resume_builder.service.PdfService;
////import org.springframework.beans.factory.annotation.Autowired;
////import org.springframework.web.bind.annotation.*;
////import org.springframework.web.multipart.MultipartFile;
////
////import java.util.Map;
////
////    @RestController
////    @RequestMapping("/api/ats")
////    @CrossOrigin("*")
////    public class AtsController {
////
////        @Autowired
////        private PdfService pdfService;
////
////        @Autowired
////        private AtsService atsService;
////
////    @PostMapping("/analyze")
////    public Object analyze(
////            @RequestParam("file") MultipartFile file,
////            @RequestParam("jobDescription") String jobDesc
////    ) {
////        try {
////            System.out.println("===== API HIT =====");
////
////            // 🔍 DEBUG
////            if (file == null) {
////                System.out.println("❌ File is NULL");
////            } else {
////                System.out.println("📄 File Name: " + file.getOriginalFilename());
////                System.out.println("📦 File Size: " + file.getSize());
////            }
////
////            if (jobDesc == null || jobDesc.isEmpty()) {
////                System.out.println("❌ Job Description is EMPTY");
////            } else {
////                System.out.println("📝 JD: " + jobDesc);
////            }
////
////            // PDF extract
////            String resumeText = pdfService.extractText(file.getInputStream());
////
////            System.out.println("📄 Extracted Resume Text (first 200 chars): ");
////            System.out.println(resumeText.substring(0, Math.min(200, resumeText.length())));
////
////            // ATS score
////            Object result = atsService.calculateScore(resumeText, jobDesc);
////
////            System.out.println("✅ ATS RESULT: " + result);
////
////            return result;
////
////        } catch (Exception e) {
////            System.out.println("🔥 ERROR OCCURRED:");
////            e.printStackTrace();
////
////            return Map.of(
////                    "status", "error",
////                    "message", e.getMessage()
////            );
////        }}}
//
//
//
//
//
//
//
//
//package com.ai.resume_builder.controller;
//
//import com.ai.resume_builder.service.AtsService;
//import com.ai.resume_builder.service.PdfService;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.web.bind.annotation.*;
//import org.springframework.web.multipart.MultipartFile;
//
//import java.util.Map;
//
//@RestController
//@RequestMapping("/api/ats")
//@CrossOrigin("*")
//public class AtsController {
//
//    @Autowired
//    private AtsService atsService;
//
//    @Autowired
//    private PdfService pdfService;
//
//    @PostMapping("/analyze")
//    public Map<String, Object> analyze(@RequestParam("file") MultipartFile file) {
//
//        try {
//            // extract text from PDF
//            String text = pdfService.extractText(file.getInputStream());
//
//            System.out.println("PDF TEXT:\n" + text);
//
//            // send to ATS service
//            return atsService.analyzeResume(text);
//
//        } catch (Exception e) {
//            e.printStackTrace();
//            return Map.of("error", e.getMessage());
//        }
//    }
//
//
//
//
//
//
//
//}





//package com.ai.resume_builder.controller;
//import com.ai.resume_builder.service.AtsService;
//import com.ai.resume_builder.service.PdfService;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.*;
//import org.springframework.web.multipart.MultipartFile;
//
//import java.util.Map;
//
//@RestController
//@RequestMapping("/api/ats")
//@CrossOrigin("*")
//public class AtsController {
//
//    @Autowired
//    private AtsService atsService;
//
//    @Autowired
//    private PdfService pdfService;
//
//    // ✅ 1. ATS ANALYZE API
//    @PostMapping("/analyze")
//    public Map<String, Object> analyze(@RequestParam("file") MultipartFile file) {
//
//        try {
//            String text = pdfService.extractText(file.getInputStream());
//
//            System.out.println("PDF TEXT:\n" + text);
//
//            return atsService.analyzeResume(text);
//
//        } catch (Exception e) {
//            e.printStackTrace();
//            return Map.of("error", e.getMessage());
//        }
//    }
//
//    // ✅ 2. ATS PDF REPORT DOWNLOAD API
//    @PostMapping("/report")
//    public ResponseEntity<byte[]> downloadReport(@RequestParam("file") MultipartFile file) {
//
//        try {
//            String text = pdfService.extractText(file.getInputStream());
//
//            Map<String, Object> result = atsService.analyzeResume(text);
//
//            byte[] pdf = pdfService.generateReport(result);
//
//            return ResponseEntity.ok()
//                    .header("Content-Disposition", "attachment; filename=ats-report.pdf")
//                    .body(pdf);
//
//        } catch (Exception e) {
//            e.printStackTrace();
//            return ResponseEntity.internalServerError().build();
//        }
//    }
//}
//
//
//
//


//package com.ai.resume_builder.controller;
//
//import com.ai.resume_builder.service.AtsService;
//import com.ai.resume_builder.service.PdfService;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.*;
//        import org.springframework.web.bind.annotation.*;
//        import org.springframework.web.multipart.MultipartFile;
//
//import java.util.Map;
//
//@RestController
//@RequestMapping("/api/ats")
//@CrossOrigin("*")
//public class AtsController {
//
//    @Autowired
//    private AtsService atsService;
//
//    @Autowired
//    private PdfService pdfService;
//
//    // ✅ 1. ATS ANALYZE API
//    @PostMapping("/analyze")
//    public ResponseEntity<?> analyze(@RequestParam("file") MultipartFile file) {
//
//        try {
//            String text = pdfService.extractText(file.getInputStream());
//
//            System.out.println("PDF TEXT:\n" + text);
//
//            Map<String, Object> result = atsService.analyzeResume(text);
//
//            return ResponseEntity.ok(result);
//
//        } catch (Exception e) {
//            e.printStackTrace();
//            return ResponseEntity.status(500)
//                    .body(Map.of("error", "ATS analysis failed"));
//        }
//    }
//
//    // ✅ 2. ATS PDF REPORT DOWNLOAD API
//    @PostMapping("/report")
//    public ResponseEntity<byte[]> downloadReport(@RequestParam("file") MultipartFile file) {
//
//        try {
//            String text = pdfService.extractText(file.getInputStream());
//
//            Map<String, Object> result = atsService.analyzeResume(text);
//
//            byte[] pdf = pdfService.generateReport(result);
//
//            return ResponseEntity.ok()
//                    .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=ats-report.pdf")
//                    .contentType(MediaType.APPLICATION_PDF)
//                    .body(pdf);
//
//        } catch (Exception e) {
//            e.printStackTrace();
//
//            return ResponseEntity.status(500)
//                    .contentType(MediaType.APPLICATION_JSON)
//                    .body(null);
//        }
//    }
//}




//        package com.ai.resume_builder.controller;
//
//import com.ai.resume_builder.service.AtsService;
//import com.ai.resume_builder.service.PdfService;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.*;
//        import org.springframework.web.bind.annotation.*;
//        import org.springframework.web.multipart.MultipartFile;
//
//import java.util.Map;
//
//@RestController
//@RequestMapping("/api/ats")
//@CrossOrigin("*")
//public class AtsController {
//
//    @Autowired
//    private AtsService atsService;
//
//    @Autowired
//    private PdfService pdfService;
//
//    // ✅ 1. ATS ANALYZE API
//    @PostMapping("/analyze")
//    public ResponseEntity<?> analyze(@RequestParam("file") MultipartFile file) {
//
//        try {
//            String text = pdfService.extractText(file.getInputStream());
//
//            System.out.println("PDF TEXT:\n" + text);
//
//            Map<String, Object> result = atsService.analyzeResume(text);
//
//            return ResponseEntity.ok(result);
//
//        } catch (Exception e) {
//            e.printStackTrace();
//            return ResponseEntity.status(500)
//                    .body(Map.of("error", "ATS analysis failed"));
//        }
//    }
//
//    // ✅ 2. ATS PDF REPORT DOWNLOAD API
//    @PostMapping("/report")
//    public ResponseEntity<byte[]> downloadReport(@RequestParam("file") MultipartFile file) {
//
//        try {
//            String text = pdfService.extractText(file.getInputStream());
//
//            Map<String, Object> result = atsService.analyzeResume(text);
//
//            byte[] pdf = pdfService.generateReport(result);
//
//            return ResponseEntity.ok()
//                    .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=ats-report.pdf")
//                    .contentType(MediaType.APPLICATION_PDF)
//                    .body(pdf);
//
//        } catch (Exception e) {
//            e.printStackTrace();
//
//            return ResponseEntity.status(500)
//                    .contentType(MediaType.APPLICATION_JSON)
//                    .body(null);
//        }
//    }
//}







package com.ai.resume_builder.controller;

import com.ai.resume_builder.service.AtsService;
import com.ai.resume_builder.service.PdfService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.Map;

@RestController
@RequestMapping("/api/ats")
@CrossOrigin("*")
public class AtsController {

    @Autowired
    private AtsService atsService;

    @Autowired
    private PdfService pdfService;

    // ✅ 1. ATS ANALYZE API
    @PostMapping("/analyze")
    public ResponseEntity<?> analyze(@RequestParam("file") MultipartFile file) {

        try {
            String text = pdfService.extractText(file.getInputStream());

            System.out.println("PDF TEXT:\n" + text);

            Map<String, Object> result = atsService.analyzeResume(text);

            return ResponseEntity.ok(result);

        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(500)
                    .body(Map.of("error", "ATS analysis failed"));
        }
    }

    // ✅ 2. ATS PDF REPORT DOWNLOAD API (FINAL FIXED)
    @PostMapping("/report")
    public ResponseEntity<byte[]> downloadReport(@RequestParam("file") MultipartFile file) {

        try {
            // 1. Extract text
            String text = pdfService.extractText(file.getInputStream());

            // 2. ATS analyze
            Map<String, Object> result = atsService.analyzeResume(text);

            // 3. Generate PDF
            byte[] pdf = pdfService.generateReport(result);

            // 🔥 DEBUG (IMPORTANT)
            System.out.println("PDF SIZE: " + (pdf != null ? pdf.length : "NULL"));

            // ❌ अगर PDF empty hai
            if (pdf == null || pdf.length == 0) {
                return ResponseEntity.status(500).build();
            }

            // ✅ Return PDF
            return ResponseEntity.ok()
                    .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=ats-report.pdf")
                    .contentType(MediaType.APPLICATION_PDF)
                    .contentLength(pdf.length)   // 🔥 IMPORTANT
                    .body(pdf);



        } catch (Exception e) {
            e.printStackTrace();

            return ResponseEntity.status(500)
                    .contentType(MediaType.APPLICATION_JSON)
                    .body(null);
        }
    }
}