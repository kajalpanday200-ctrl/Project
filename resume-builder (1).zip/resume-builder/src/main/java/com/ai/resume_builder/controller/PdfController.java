package com.ai.resume_builder.controller;

import com.ai.resume_builder.service.PdfService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@RestController
@RequestMapping("/api/pdf")
@CrossOrigin("*")
public class PdfController {

    @Autowired
    private PdfService pdfService;

    @PostMapping("/upload")
    public String uploadPdf(@RequestParam("file") MultipartFile file) {

        try {
            String text = pdfService.extractText(file.getInputStream());

            System.out.println("PDF TEXT:\n" + text);

            return text;

        } catch (Exception e) {
            e.printStackTrace();
            return "Error: " + e.getMessage();
        }
    }
}