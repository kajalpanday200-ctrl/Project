//package com.ai.resume_builder.dto;
//
//import lombok.Getter;
//import lombok.Setter;
//
//@Setter
//@Getter
//public class PromptRequest {
//
//        private String prompt;
//
//}
//
//



package com.ai.resume_builder.dto;

import lombok.Getter;
import lombok.Setter;

import jakarta.validation.constraints.NotBlank;

@Setter
@Getter
public class PromptRequest {

        @NotBlank(message = "Prompt cannot be empty")
        private String prompt;

    public String getName() {
        return null;
    }

    public String getEmail() {
        return null;
    }

    public String getSkills() {
        return null;
    }

    public String getEducation() {
        return null;
    }

    public String getExperience() {
        return null;
    }
}




