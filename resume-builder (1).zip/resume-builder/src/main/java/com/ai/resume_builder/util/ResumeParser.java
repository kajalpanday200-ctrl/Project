package com.ai.resume_builder.util;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
import org.springframework.web.multipart.MultipartFile;

public class ResumeParser {

    public static String parse(MultipartFile file) {
        try {
            PDDocument doc = PDDocument.load(file.getInputStream());
            return new PDFTextStripper().getText(doc);
        } catch (Exception e) {
            return "";
        }
    }
}