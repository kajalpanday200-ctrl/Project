package com.ai.resume_builder.dto;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Setter
@Getter
public class SkillGapResponse {

    private List<String> matchedSkills;
    private List<String> missingSkills;
    private List<String> recommendedSkills;   // ✅ ADD THIS
    private String suggestion;

}