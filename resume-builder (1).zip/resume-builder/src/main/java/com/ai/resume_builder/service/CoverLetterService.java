package com.ai.resume_builder.service;



import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.util.HashMap;
import java.util.Map;

@Service
public class CoverLetterService {

    public Map<String, Object> extractResume(MultipartFile file) {

        Map<String, Object> map = new HashMap<>();

        try {
            if (file == null || file.isEmpty()) {
                map.put("status", "error");
                map.put("message", "File is empty");
                return map;
            }

            System.out.println("File name: " + file.getOriginalFilename());
            System.out.println("File size: " + file.getSize());

            PDDocument document = PDDocument.load(file.getInputStream());
            PDFTextStripper stripper = new PDFTextStripper();
            String text = stripper.getText(document);
            document.close();

            System.out.println("Extracted Text: " + text);

            map.put("status", "success");
            map.put("text", text);

            return map;

        } catch (Exception e) {
            e.printStackTrace();

            map.put("status", "error");
            map.put("message", e.getMessage());

            return map;

        }
    }


}

