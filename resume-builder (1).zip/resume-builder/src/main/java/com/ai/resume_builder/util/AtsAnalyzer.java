//package com.ai.resume_builder.util;
//
//import java.util.*;
//
//public class AtsAnalyzer {
//
//    private static final List<String> KEYWORDS = Arrays.asList(
//            "java", "spring", "boot", "mongodb", "sql", "docker", "api"
//    );
//
//    public static Map<String, Object> analyze(String text) {
//
//        text = text.toLowerCase();
//
//        List<String> matched = new ArrayList<>();
//        List<String> missing = new ArrayList<>();
//
//        for (String k : KEYWORDS) {
//            if (text.contains(k)) matched.add(k);
//            else missing.add(k);
//        }
//
//        int score = (matched.size() * 100) / KEYWORDS.size();
//
//        Map<String, Object> result = new HashMap<>();
//        result.put("score", score);
//        result.put("matchedKeywords", matched);
//        result.put("missingKeywords", missing);
//
//        return result;
//    }
//}




package com.ai.resume_builder.util;

import java.util.*;

public class AtsAnalyzer {

    private static final List<String> KEYWORDS = Arrays.asList(
            "java", "spring", "boot", "mongodb", "sql", "docker", "api"
    );

    public static Map<String, Object> analyze(String text) {

        text = text.toLowerCase();

        List<String> matched = new ArrayList<>();
        List<String> missing = new ArrayList<>();

        for (String k : KEYWORDS) {
            if (text.contains(k)) matched.add(k);
            else missing.add(k);
        }

        int score = (matched.size() * 100) / KEYWORDS.size();

        Map<String, Object> result = new HashMap<>();
        result.put("score", score);
        result.put("matchedKeywords", matched);
        result.put("missingKeywords", missing);

        return result;
    }
}