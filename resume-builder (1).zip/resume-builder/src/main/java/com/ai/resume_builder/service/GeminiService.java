//package com.ai.resume_builder.service;
//
//import org.springframework.stereotype.Service;
//
//import java.io.BufferedReader;
//import java.io.InputStreamReader;
//import java.net.HttpURLConnection;
//import java.net.URL;
//import java.util.stream.Collectors;
//
//@Service
//public class GeminiService {
//
//    public String generateCoverLetter(String name) throws Exception {
//
//        String apiKey = "PASTE_YOUR_GEMINI_API_KEY";
//
//        URL url = new URL(
//                "https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key=" + apiKey
//        );
//
//        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
//        conn.setRequestMethod("POST");
//        conn.setDoOutput(true);
//        conn.setRequestProperty("Content-Type", "application/json");
//
//        String body = """
//        {
//          "contents":[{"parts":[{"text":"Write a professional cover letter for %s"}]}]
//        }
//        """.formatted(name);
//
//        conn.getOutputStream().write(body.getBytes());
//
//        BufferedReader br = new BufferedReader(
//                new InputStreamReader(conn.getInputStream())
//        );
//
//        return br.lines().collect(Collectors.joining());
//    }
//}



//package com.ai.resume_builder.service;
//
//import org.springframework.stereotype.Service;
//
//@Service
//public class GeminiService {
//
//    public String generateCoverLetter(String name){
//        return "Cover Letter for " + name;
//    }
//}


//package com.ai.resume_builder.service;
//
//import org.springframework.stereotype.Service;
//
//import java.io.*;
//import java.net.*;
//
//@Service
//public class GeminiService {
//
//    public String generateCoverLetter(String name) throws Exception {
//
//        String apiKey = "YOUR_API_KEY";
//
//        URL url = new URL(
//                "https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key=" + apiKey);
//
//        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
//        conn.setRequestMethod("POST");
//        conn.setDoOutput(true);
//
//        String body = """
//        {
//          "contents":[{"parts":[{"text":"Write a professional cover letter for %s"}]}]
//        }
//        """.formatted(name);
//
//        conn.getOutputStream().write(body.getBytes());
//
//        BufferedReader br = new BufferedReader(
//                new InputStreamReader(conn.getInputStream()));
//
//        StringBuilder sb = new StringBuilder();
//        String line;
//
//        while((line = br.readLine()) != null){
//            sb.append(line);
//        }
//
//        return sb.toString();
//    }
//    public String generateContent(String prompt) throws Exception {
//
//        // 🔥 yaha tum Gemini API call karoge
//        // फिलहाल dummy return कर रहा हूँ
//
//        return """
//    {
//      "name": "Kajal Panday",
//      "email": "kajal@gmail.com",
//      "education": "MCA",
//      "skills": ["Java","Spring Boot","MongoDB"],
//      "projects": ["AI Resume Builder"],
//      "experience": "Fresher",
//      "certificates": "Java Certification",
//      "github": "github.com/kajal",
//      "linkedin": "linkedin.com/kajal"
//    }
//    """;
//
//
//   }}




//package com.ai.resume_builder.service;
//
//import com.ai.resume_builder.model.Resume;
//import com.fasterxml.jackson.databind.ObjectMapper;
//import org.springframework.stereotype.Service;
//
//import java.net.URI;
//import java.net.http.HttpClient;
//import java.net.http.HttpRequest;
//import java.net.http.HttpResponse;
//
//@Service
//public class GeminiService {
//
//    private static final String API_KEY = "YOUR_GEMINI_API_KEY";
//    private static final String GEMINI_URL =
//            "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=" + API_KEY;
//
//    private final ObjectMapper mapper = new ObjectMapper();
//
//    // ================= MAIN FUNCTION =================
//    public Resume generateResume(String prompt) throws Exception {
//
//        String aiResponse = callGeminiAPI(prompt);
//
//        // 🧠 clean response (VERY IMPORTANT)
//        aiResponse = cleanJson(aiResponse);
//
//        // 🔥 convert JSON → Resume class
//        return mapper.readValue(aiResponse, Resume.class);
//    }
//
//    // ================= GEMINI API CALL =================
//    private String callGeminiAPI(String prompt) throws Exception {
//
//        String requestBody = """
//        {
//          "contents": [
//            {
//              "parts": [
//                {
//                  "text": "Convert this into STRICT JSON resume format only. No explanation. No markdown. Only JSON.\\n\\n"""
//                + prompt +
//                """
//                \\n\\nFormat:
//                {
//                  "name": "",
//                  "email": "",
//                  "education": "",
//                  "skills": [],
//                  "projects": [],
//                  "experience": "",
//                  "certificates": "",
//                  "github": "",
//                  "linkedin": ""
//                }
//                "
//                }
//              ]
//            }
//          ]
//        }
//        """;
//
//        HttpRequest request = HttpRequest.newBuilder()
//                .uri(URI.create(GEMINI_URL))
//                .header("Content-Type", "application/json")
//                .POST(HttpRequest.BodyPublishers.ofString(requestBody))
//                .build();
//
//        HttpClient client = HttpClient.newHttpClient();
//
//        HttpResponse<String> response =
//                client.send(request, HttpResponse.BodyHandlers.ofString());
//
//        // 🔥 extract actual text from Gemini response
//        return extractText(response.body());
//    }
//
//    // ================= EXTRACT TEXT =================
//    private String extractText(String responseBody) {
//
//        try {
//            // Gemini response parsing
//            return mapper.readTree(responseBody)
//                    .path("candidates")
//                    .get(0)
//                    .path("content")
//                    .path("parts")
//                    .get(0)
//                    .path("text")
//                    .asText();
//        } catch (Exception e) {
//            return "{}";
//        }
//    }
//
//    // ================= CLEAN JSON =================
//    private String cleanJson(String text) {
//
//        if (text == null) return "{}";
//
//        text = text.replace("```json", "");
//        text = text.replace("```", "");
//
//        return text.trim();
//    }
//
//    public String generateCoverLetter(String name) {
//        return null;
//    }
//
//    public String generateContent(String finalPrompt) {
//        return null;
//    }
//}





package com.ai.resume_builder.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.*;

@Service
public class GeminiService {

    @Value("${gemini.api.key}")
    private String apiKey;

    @Value("${gemini.api.url}")
    private String apiUrl;

    public String getATSAnalysis(String resumeText, String jobDescription, String type) {

        String prompt = buildPrompt(resumeText, jobDescription, type);

        Map<String, Object> requestBody = new HashMap<>();
        Map<String, Object> content = new HashMap<>();
        content.put("parts", List.of(Map.of("text", prompt)));

        requestBody.put("contents", List.of(content));

        RestTemplate restTemplate = new RestTemplate();

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);

        HttpEntity<Map<String, Object>> entity = new HttpEntity<>(requestBody, headers);

        String url = apiUrl + "?key=" + apiKey;

        ResponseEntity<String> response =
                restTemplate.postForEntity(url, entity, String.class);

        return response.getBody();
    }

    private String buildPrompt(String resume, String job, String type) {

        if ("QUICK".equalsIgnoreCase(type)) {
            return """
            You are ResumeChecker AI.

            1. Give ATS score out of 100
            2. 3 strengths
            3. 2 improvements

            Resume:
            """ + resume + "\nJob:\n" + job;
        }

        if ("ATS".equalsIgnoreCase(type)) {
            return """
            You are ATS optimization expert.

            1. Extract keywords from job description
            2. Suggest improvements
            3. ATS score out of 100 with reason

            Resume:
            """ + resume + "\nJob:\n" + job;
        }

        return """
        Provide detailed resume analysis:
        """ + resume;
    }
}