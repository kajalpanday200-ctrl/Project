//package com.ai.resume_builder.service;
//
//import com.ai.resume_builder.dto.AtsRequest;
//import com.ai.resume_builder.dto.SkillGapResponse;
//import org.springframework.stereotype.Service;
//
//import java.util.*;
//
//@Service
//public class SkillGapService {
//
//    public SkillGapResponse analyzeGap(AtsRequest request) {
//
//        String jd = request.getJobDescription().toLowerCase();
//        String resume = request.getResumeText().toLowerCase();
//
//        Set<String> jdKeywords = extractKeywords(jd);
//        Set<String> resumeKeywords = extractKeywords(resume);
//
//        List<String> matched = new ArrayList<>();
//        List<String> missing = new ArrayList<>();
//
//        for (String skill : jdKeywords) {
//            if (resumeKeywords.contains(skill)) {
//                matched.add(skill);
//            } else {
//                missing.add(skill);
//            }
//        }
//
//        SkillGapResponse response = new SkillGapResponse();
//        response.setMatchedSkills(matched);
//        response.setMissingSkills(missing);
//        response.setRecommendedSkills(missing);
//
//        response.setSuggestion(
//                missing.isEmpty()
//                        ? "Great! No skill gap found."
//                        : "You should improve: " + missing
//        );
//
//        return response;
//    }
//
//    private Set<String> extractKeywords(String text) {
//
//        text = text.replaceAll("[^a-zA-Z ]", " ");
//
//        String[] words = text.split("\\s+");
//
//        List<String> stopWords = Arrays.asList(
//                "i","am","a","an","the","and","or","to","in","for","with","on","of","is","are"
//        );
//
//        Set<String> result = new HashSet<>();
//
//        for (String w : words) {
//            if (w.length() > 2 && !stopWords.contains(w)) {
//                result.add(w);
//            }
//        }
//
//        return result;
//    }
//}



package com.ai.resume_builder.service;

import com.ai.resume_builder.dto.AtsRequest;
import com.ai.resume_builder.dto.SkillGapResponse;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class SkillGapService {

    public SkillGapResponse analyzeGap(AtsRequest request) {
        return analyze(request);
    }

    public SkillGapResponse analyze(AtsRequest request) {

        Set<String> jd = extract(request.getJobDescription());
        Set<String> resume = extract(request.getResumeText());


        List<String> matched = new ArrayList<>();
        List<String> missing = new ArrayList<>();

        for (String skill : jd) {
            if (resume.contains(skill)) {
                matched.add(skill);
            } else {
                missing.add(skill);
            }
        }

        SkillGapResponse response = new SkillGapResponse();

        response.setMatchedSkills(matched);
        response.setMissingSkills(missing);
        response.setRecommendedSkills(missing);

        response.setSuggestion(
                missing.isEmpty()
                        ? "Great! No skill gap"
                        : "Improve these skills: " + missing
        );

        return response;
    }

    private Set<String> extract(String text) {

        text = text.toLowerCase().replaceAll("[^a-zA-Z ]", " ");
        String[] words = text.split("\\s+");

        Set<String> set = new HashSet<>();

        for (String w : words) {
            if (w.length() > 2) {
                set.add(w);
            }
        }

        return set;
    }
}