////////package com.ai.resume_builder.controller;
////////import com.ai.resume_builder.dto.PromptRequest;
////////import com.ai.resume_builder.service.AiResumeService;
////////import org.springframework.beans.factory.annotation.Autowired;
////////import org.springframework.web.bind.annotation.*;
////////
////////import java.util.Map;
////////
////////    @RestController
////////    @RequestMapping("/api/ai")
////////    @CrossOrigin("*")
////////    public class AIController {
////////
////////        @Autowired
////////        private AiResumeService.AIResumeService service;
////////
////////        @PostMapping("/generate")
////////        public Map generate(@RequestBody PromptRequest request) throws Exception {
////////            return service.generateResume(request.getPrompt());
////////        }
////////    }
////////
////////
////////
//////
//////
//////package com.ai.resume_builder.controller;
//////
//////import com.ai.resume_builder.dto.PromptRequest;
//////import com.ai.resume_builder.service.AiResumeService;
//////import org.springframework.beans.factory.annotation.Autowired;
//////import org.springframework.web.bind.annotation.*;
//////
//////import java.util.Map;
//////
//////@RestController
//////@RequestMapping("/api/ai")
//////@CrossOrigin("*")
//////public class AIController {
//////
//////    @Autowired
//////    private AiResumeService service;
//////
//////    // ✅ AI RESUME GENERATION
//////    @PostMapping("/generate")
//////    public Map<String, Object> generate(@RequestBody PromptRequest request) {
//////
//////        try {
//////            return service.generateResume(request.getPrompt());
//////        }
//////        catch (Exception e) {
//////            return Map.of(
//////                    "error", true,
//////                    "message", "AI generation failed",
//////                    "details", e.getMessage()
//////            );
//////        }
//////    }
//////}
////
////
////
//////package com.ai.resume_builder.controller;
//////import com.ai.resume_builder.dto.PromptRequest;
//////import com.ai.resume_builder.service.AiResumeService;
//////import org.springframework.beans.factory.annotation.Autowired;
//////import org.springframework.web.bind.annotation.*;
//////
//////import java.util.Map;
//////
//////@RestController
//////@RequestMapping("/api/ai")
//////@CrossOrigin("*")
//////public class AIController {
//////
//////    @Autowired
//////    private AiResumeService service;
//////
//////    // ================= AI RESUME GENERATION =================
//////    @PostMapping("/generate")
//////    public Map<String, Object> generate(@RequestBody PromptRequest request) {
//////
//////        Map<String, Object> result = service.generateResume(request.getPrompt());
//////
//////        return Map.of(
//////                "success", true,
//////                "data", result
//////        );
//////    }
//////
////
////
////
////
//////    @PostMapping("/generate")
//////    public ResponseEntity<Map<String, Object>> generate(@RequestBody PromptRequest request) {
//////
//////        // 🔒 validation
//////        if (request == null || request.getPrompt() == null || request.getPrompt().trim().isEmpty()) {
//////            return ResponseEntity.badRequest().body(
//////                    Map.of(
//////                            "success", false,
//////                            "message", "Prompt cannot be empty"
//////                    )
//////            );
//////        }
//////
//////        try {
//////            Map<String, Object> result = service.generateResume(request.getPrompt());
//////
//////            return ResponseEntity.ok(
//////                    Map.of(
//////                            "success", true,
//////                            "data", result
//////                    )
//////            );
//////
//////        } catch (Exception e) {
//////
//////            return ResponseEntity.internalServerError().body(
//////                    Map.of(
//////                            "success", false,
//////                            "message", "AI generation failed",
//////                            "error", e.getMessage()
//////                    )
//////            );
////       // }
////    //}
//////}
////
////
////
////
////
////package com.ai.resume_builder.controller;
////
////import com.ai.resume_builder.dto.PromptRequest;
////import com.ai.resume_builder.service.AiResumeService;
////import org.springframework.beans.factory.annotation.Autowired;
////import org.springframework.http.ResponseEntity;
////import org.springframework.web.bind.annotation.*;
////
////import java.util.Map;
////
////@RestController
////@RequestMapping("/api/ai")
////@CrossOrigin("*")
////public class AIController {
////
////    @Autowired
////    private AiResumeService service;
////
////    // ================= AI RESUME GENERATION =================
////    @PostMapping("/generate")
////    public ResponseEntity<?> generate(@RequestBody PromptRequest request) {
////
////        try {
////            Map<String, Object> result = service.generateResume(request.getPrompt());
////
////            return ResponseEntity.ok(
////                    Map.of(
////                            "success", true,
////                            "message", "Resume generated successfully",
////                            "data", result
////                    )
////            );
////
////        } catch (Exception e) {
////
////            return ResponseEntity.status(500).body(
////                    Map.of(
////                            "success", false,
////                            "message", "AI generation failed",
////                            "error", e.getMessage()
////                    )
////            );
////        }
////    }
////}
//
//
//
//
////package com.ai.resume_builder.controller;
////
////import com.ai.resume_builder.dto.PromptRequest;
////import com.ai.resume_builder.service.AiResumeService;
////import org.springframework.beans.factory.annotation.Autowired;
////import org.springframework.http.ResponseEntity;
////import org.springframework.web.bind.annotation.*;
////
////import java.util.Map;
////
////@RestController
////@RequestMapping("/api/ai")
////@CrossOrigin("*")
////public class AIController {
////
////    @Autowired
////    private AiResumeService service;
////
////    @PostMapping("/generate")
////    public ResponseEntity<?> generate(@RequestBody PromptRequest request) {
////
////        try {
////            Map<String, Object> result = service.generateResume(request.getPrompt());
////
////            return ResponseEntity.ok(
////                    Map.of(
////                            "success", true,
////                            "message", "Resume generated successfully",
////                            "data", result
////                    )
////            );
////
////        } catch (Exception e) {
////
////            return ResponseEntity.status(500).body(
////                    Map.of(
////                            "success", false,
////                            "message", "AI generation failed",
////                            "error", e.getMessage()
////                    )
////            );
////        }
////    }}
//
//
//
//
//
//package com.ai.resume_builder.controller;
//
//
//import com.ai.resume_builder.dto.PromptRequest;
//import com.ai.resume_builder.service.AiResumeService;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.*;
//
//import java.util.Map;
//
//@RestController
//@RequestMapping("/api/ai")
//@CrossOrigin(origins = "*")
//public class AIController {
//
//    @Autowired
//    private AiResumeService service;
//
//    @PostMapping("/generate")
//    public ResponseEntity<?> generate(@RequestBody PromptRequest request) {
//
//        try {
//
//            // 🔥 IMPORTANT FIX: null safety
//            if (request.getPrompt() == null || request.getPrompt().trim().isEmpty()) {
//                return ResponseEntity.badRequest().body(
//                        Map.of(
//                                "success", false,
//                                "message", "Prompt cannot be empty"
//                        )
//                );
//            }
//
//            Map<String, Object> result = service.generateResume(request.getPrompt());
//
//            return ResponseEntity.ok(
//                    Map.of(
//                            "success", true,
//                            "message", "Resume generated successfully",
//                            "data", result
//                    )
//            );
//
//        } catch (Exception e) {
//
//            return ResponseEntity.status(500).body(
//                    Map.of(
//                            "success", false,
//                            "message", "AI generation failed",
//                            "error", e.getMessage()
//                    )
//            );
//        }
//    }
//}
//
//


package com.ai.resume_builder.controller;

import com.ai.resume_builder.dto.PromptRequest;
import com.ai.resume_builder.service.AiResumeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/ai")
@CrossOrigin(origins = "*")
public class AIController {

    @Autowired
    private AiResumeService service;

    @PostMapping("/generate")
    public ResponseEntity<?> generate(@RequestBody PromptRequest request) {

        try {

            // ✅ CASE 1: Direct prompt (Postman testing)
            String prompt = request.getPrompt();

            // ✅ CASE 2: Agar frontend se fields aaye ho (future ready)
            if ((prompt == null || prompt.trim().isEmpty())
                    && request.getName() != null) {

                prompt = "Create resume for:\n"
                        + "Name: " + request.getName() + "\n"
                        + "Email: " + request.getEmail() + "\n"
                        + "Skills: " + request.getSkills() + "\n"
                        + "Education: " + request.getEducation() + "\n"
                        + "Experience: " + request.getExperience();
            }

            // ❌ FINAL validation
            if (prompt == null || prompt.trim().isEmpty()) {
                return ResponseEntity.badRequest().body(
                        Map.of(
                                "success", false,
                                "message", "Prompt cannot be empty"
                        )
                );
            }

            // 🔥 DEBUG (console me check kar sakte ho)
            System.out.println("FINAL PROMPT: " + prompt);

            Map<String, Object> result = service.generateResume(prompt);

            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("message", "Resume generated successfully");
            response.put("data", result);

            return ResponseEntity.ok(response);

        } catch (Exception e) {

            e.printStackTrace();

            return ResponseEntity.status(500).body(
                    Map.of(
                            "success", false,
                            "message", "AI generation failed",
                            "error", e.getMessage()
                    )
            );
        }
    }
}