//package com.ai.resume_builder.service;
//
//import com.ai.resume_builder.util.AtsAnalyzer;
//import org.springframework.stereotype.Service;
//
//import java.util.Map;
//
//@Service
//public class AtsService {
//
//    public Map<String, Object> analyzeResume(String resumeText) {
//        return AtsAnalyzer.analyze(resumeText);
//    }
//}



//package com.ai.resume_builder.service;
//
//import org.springframework.stereotype.Service;
//
//import java.util.*;
//
//@Service
//public class AtsService {
//
//    private static final List<String> KEYWORDS = List.of(
//            "java", "spring", "boot", "mongodb", "sql",
//            "api", "docker", "microservices", "hibernate"
//    );
//
//    public Map<String, Object> analyzeResume(String text) {
//
//        String resume = text.toLowerCase();
//
//        List<String> matched = new ArrayList<>();
//        List<String> missing = new ArrayList<>();
//
//        for (String key : KEYWORDS) {
//            if (resume.contains(key)) {
//                matched.add(key);
//            } else {
//                missing.add(key);
//            }
//        }
//
//        int score = (int) ((matched.size() * 100.0) / KEYWORDS.size());
//
//        Map<String, Object> response = new HashMap<>();
//        response.put("score", score);
//        response.put("matchedKeywords", matched);
//        response.put("missingKeywords", missing);
//
//        return response;
//    }
//}
//
//
//


//package com.ai.resume_builder.service;
//import org.springframework.stereotype.Service;
//import java.util.*;
//
//@Service
//public class AtsService {
//
//    public Map<String, Object> analyzeResume(String resumeText) {
//
//        resumeText = resumeText.toLowerCase();
//
//        // 🎯 Job Keywords (you can make dynamic later)
//        Map<String, Integer> keywordWeights = new HashMap<>();
//
//        keywordWeights.put("java", 10);
//        keywordWeights.put("spring", 10);
//        keywordWeights.put("boot", 10);
//        keywordWeights.put("hibernate", 8);
//        keywordWeights.put("sql", 8);
//        keywordWeights.put("api", 8);
//        keywordWeights.put("microservices", 10);
//        keywordWeights.put("mongodb", 8);
//        keywordWeights.put("docker", 8);
//
//        List<String> matched = new ArrayList<>();
//        List<String> missing = new ArrayList<>();
//
//        int totalWeight = 0;
//        int matchedWeight = 0;
//
//        for (Map.Entry<String, Integer> entry : keywordWeights.entrySet()) {
//
//            totalWeight += entry.getValue();
//
//            if (resumeText.contains(entry.getKey())) {
//                matched.add(entry.getKey());
//                matchedWeight += entry.getValue();
//            } else {
//                missing.add(entry.getKey());
//            }
//        }
//
//        // 🎯 Score Calculation
//        int score = (int) (((double) matchedWeight / totalWeight) * 100);
//
//        // 📊 Suggestions
//        String suggestion;
//        if (score > 85) {
//            suggestion = "Excellent resume 🔥";
//        } else if (score > 70) {
//            suggestion = "Good resume 👍 but can improve";
//        } else {
//            suggestion = "Needs improvement ❗ Add missing skills";
//        }
//
//        return Map.of(
//                "score", score,
//                "matchedKeywords", matched,
//                "missingKeywords", missing,
//                "suggestion", suggestion
//        );
//    }
//}
//










package com.ai.resume_builder.service;

import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class AtsService {

    public Map<String, Object> analyzeResume(String resumeText) {

        resumeText = resumeText.toLowerCase();

        // 🎯 Job Keywords (you can make dynamic later)
        Map<String, Integer> keywordWeights = new HashMap<>();

        keywordWeights.put("java", 10);
        keywordWeights.put("spring", 10);
        keywordWeights.put("boot", 10);
        keywordWeights.put("hibernate", 8);
        keywordWeights.put("sql", 8);
        keywordWeights.put("api", 8);
        keywordWeights.put("microservices", 10);
        keywordWeights.put("mongodb", 8);
        keywordWeights.put("docker", 8);

        List<String> matched = new ArrayList<>();
        List<String> missing = new ArrayList<>();

        int totalWeight = 0;
        int matchedWeight = 0;

        for (Map.Entry<String, Integer> entry : keywordWeights.entrySet()) {

            totalWeight += entry.getValue();

            if (resumeText.contains(entry.getKey())) {
                matched.add(entry.getKey());
                matchedWeight += entry.getValue();
            } else {
                missing.add(entry.getKey());
            }
        }

        // 🎯 Score Calculation
        int score = (int) (((double) matchedWeight / totalWeight) * 100);

        // 📊 Suggestions
        String suggestion;
        if (score > 85) {
            suggestion = "Excellent resume 🔥";
        } else if (score > 70) {
            suggestion = "Good resume 👍 but can improve";
        } else {
            suggestion = "Needs improvement ❗ Add missing skills";
        }

        return Map.of(
                "score", score,
                "matchedKeywords", matched,
                "missingKeywords", missing,
                "suggestion", suggestion
        );
    }
}



