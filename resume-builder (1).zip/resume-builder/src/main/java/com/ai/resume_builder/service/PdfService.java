//package com.ai.resume_builder.service;
//import org.apache.pdfbox.pdmodel.PDDocument;
//import org.springframework.beans.factory.aot.AotServices;
//import org.springframework.stereotype.Service;
//
//import java.io.InputStream;
//
//@Service
//public class PdfService<PDFTextStripper> {
//
//    public String extractText(InputStream file) {
//
//        try (org.apache.pdfbox.pdmodel.PDDocument document =
//                     org.apache.pdfbox.pdmodel.PDDocument.load(file)) {
//
//            org.apache.pdfbox.text.PDFTextStripper stripper =
//                    new org.apache.pdfbox.text.PDFTextStripper();
//
//            return stripper.getText(document);
//
//        } catch (Exception e) {
//            throw new RuntimeException("PDF Error: " + e.getMessage());
//        }
//    }}
//package com.ai.resume_builder.service;
//
//import org.apache.pdfbox.pdmodel.PDDocument;
//import org.apache.pdfbox.text.PDFTextStripper;
//import org.springframework.stereotype.Service;
//
//import java.io.InputStream;
//
//@Service
//public class PdfService {
//
//    public String extractText(InputStream file) {
//        try (PDDocument document = PDDocument.load(file)) {
//            PDFTextStripper stripper = new PDFTextStripper();
//            return stripper.getText(document);
//        } catch (Exception e) {
//            throw new RuntimeException("PDF Read Error: " + e.getMessage());
//        }
//    }
//}




//package com.ai.resume_builder.service;
//
//import org.apache.pdfbox.pdmodel.PDDocument;
//import org.apache.pdfbox.text.PDFTextStripper;
//import org.springframework.stereotype.Service;
//
//import java.io.InputStream;
//import java.util.Map;
//
//@Service
//public class PdfService {
//
//    public String extractText(InputStream inputStream) {
//        try (PDDocument document = PDDocument.load(inputStream)) {
//            PDFTextStripper stripper = new PDFTextStripper();
//            return stripper.getText(document);
//        } catch (Exception e) {
//            throw new RuntimeException("PDF read error: " + e.getMessage());
//        }
//    }}package com.ai.resume_builder.service;
//
//import org.apache.pdfbox.pdmodel.*;
//import org.apache.pdfbox.pdmodel.font.PDType1Font;
//import org.springframework.stereotype.Service;
//
//import java.io.ByteArrayOutputStream;
//import java.util.List;
//import java.util.Map;
//
//@Service
//public class PdfReportService {
//
//    public byte[] generateReport(Map<String, Object> data) {
//
//        try (PDDocument document = new PDDocument()) {
//
//            PDPage page = new PDPage();
//            document.addPage(page);
//
//            PDPageContentStream content = new PDPageContentStream(document, page);
//
//            content.beginText();
//            content.setFont(PDType1Font.HELVETICA_BOLD, 18);
//            content.setLeading(14.5f);
//            content.newLineAtOffset(50, 700);
//
//            // Title
//            content.showText("ATS Resume Report");
//            content.newLine();
//            content.newLine();
//
//            // Score
//            content.setFont(PDType1Font.HELVETICA, 12);
//            content.showText("Score: " + data.get("score"));
//            content.newLine();
//
//            // Matched
//            content.showText("Matched Keywords:");
//            content.newLine();
//
//            List<String> matched = (List<String>) data.get("matchedKeywords");
//            for (String m : matched) {
//                content.showText("- " + m);
//                content.newLine();
//            }
//
//            content.newLine();
//
//            // Missing
//            content.showText("Missing Keywords:");
//            content.newLine();
//
//            List<String> missing = (List<String>) data.get("missingKeywords");
//            for (String m : missing) {
//                content.showText("- " + m);
//                content.newLine();
//            }
//
//            content.newLine();
//
//            // Suggestion
//            content.showText("Suggestion: " + data.get("suggestion"));
//
//            content.endText();
//            content.close();
//
//            ByteArrayOutputStream out = new ByteArrayOutputStream();
//            document.save(out);
//
//            return out.toByteArray();
//
//        } catch (Exception e) {
//            e.printStackTrace();
//            return null;
//        }
//    }
//}





//package com.ai.resume_builder.service;
//
//import org.apache.pdfbox.pdmodel.*;
//        import org.apache.pdfbox.pdmodel.font.PDType1Font;
//import org.springframework.stereotype.Service;
//
//import java.io.ByteArrayOutputStream;
//import java.io.InputStream;
//import java.util.List;
//import java.util.Map;
//
//@Service
//public class PdfService {
//
//    public byte[] generateReport(Map<String, Object> data) {
//
//        try (PDDocument document = new PDDocument()) {
//
//            PDPage page = new PDPage();
//            document.addPage(page);
//
//            PDPageContentStream content = new PDPageContentStream(document, page);
//
//            content.beginText();
//            content.setFont(PDType1Font.HELVETICA_BOLD, 18);
//            content.setLeading(14.5f);
//            content.newLineAtOffset(50, 700);
//
//            // Title
//            content.showText("ATS Resume Report");
//            content.newLine();
//            content.newLine();
//
//            // Score
//            content.setFont(PDType1Font.HELVETICA, 12);
//            content.showText("Score: " + data.get("score"));
//            content.newLine();
//
//            // Matched
//            content.showText("Matched Keywords:");
//            content.newLine();
//
//            List<String> matched = (List<String>) data.get("matchedKeywords");
//            for (String m : matched) {
//                content.showText("- " + m);
//                content.newLine();
//            }
//
//            content.newLine();
//
//            // Missing
//            content.showText("Missing Keywords:");
//            content.newLine();
//
//            List<String> missing = (List<String>) data.get("missingKeywords");
//            for (String m : missing) {
//                content.showText("- " + m);
//                content.newLine();
//            }
//
//            content.newLine();
//
//            // Suggestion
//            content.showText("Suggestion: " + data.get("suggestion"));
//
//            content.endText();
//            content.close();
//
//            ByteArrayOutputStream out = new ByteArrayOutputStream();
//            document.save(out);
//
//            return out.toByteArray();
//
//        } catch (Exception e) {
//            e.printStackTrace();
//            return null;
//        }
//
//    public String extractText(InputStream Object inputStream;
//        inputStream){
//
//            try {
//                PDDocument document = new PDDocument();
//                PDPage page = new PDPage();
//                document.addPage(page);
//
//
//            }
//        }
//
//
//



//package com.ai.resume_builder.service;
//
//import org.apache.pdfbox.pdmodel.PDDocument;
//import org.apache.pdfbox.text.PDFTextStripper;
//import org.apache.pdfbox.pdmodel.*;
//import org.apache.pdfbox.pdmodel.font.PDType1Font;
//import org.springframework.stereotype.Service;
//
//import java.io.ByteArrayOutputStream;
//import java.io.InputStream;
//import java.util.List;
//import java.util.Map;
//
//@Service
//public class PdfService {
//
//    // ✅ Extract text from PDF
//    public String extractText(InputStream inputStream) {
//        try (PDDocument document = PDDocument.load(inputStream)) {
//            PDFTextStripper pdfStripper = new PDFTextStripper();
//            return pdfStripper.getText(document);
//        } catch (Exception e) {
//            e.printStackTrace();
//            return "";
//        }
//    }
//
//    // ✅ Generate ATS Report PDF
//    public byte[] generateReport(Map<String, Object> data) {
//
//        try (PDDocument document = new PDDocument()) {
//
//            PDPage page = new PDPage();
//            document.addPage(page);
//
//            PDPageContentStream content = new PDPageContentStream(document, page);
//
//            content.beginText();
//            content.setFont(PDType1Font.HELVETICA_BOLD, 18);
//            content.setLeading(14.5f);
//            content.newLineAtOffset(50, 700);
//
//            content.showText("ATS Resume Report");
//            content.newLine();
//            content.newLine();
//
//            content.setFont(PDType1Font.HELVETICA, 12);
//
//            content.showText("Score: " + data.get("score"));
//            content.newLine();
//
//            content.showText("Matched Keywords:");
//            content.newLine();
//
//            List<String> matched = (List<String>) data.get("matchedKeywords");
//            for (String m : matched) {
//                content.showText("- " + m);
//                content.newLine();
//            }
//
//            content.newLine();
//
//            content.showText("Missing Keywords:");
//            content.newLine();
//
//            List<String> missing = (List<String>) data.get("missingKeywords");
//            for (String m : missing) {
//                content.showText("- " + m);
//                content.newLine();
//            }
//
//            content.newLine();
//
//            content.showText("Suggestion: " + data.get("suggestion"));
//
//            content.endText();
//            content.close();
//
//            ByteArrayOutputStream out = new ByteArrayOutputStream();
//            document.save(out);
//
//            return out.toByteArray();
//
//        } catch (Exception e) {
//            e.printStackTrace();
//            return null;
//        }
//    }
//}


//package com.ai.resume_builder.service;
//
//import org.apache.pdfbox.pdmodel.PDDocument;
//import org.apache.pdfbox.text.PDFTextStripper;
//import org.apache.pdfbox.pdmodel.*;
//import org.apache.pdfbox.pdmodel.font.PDType1Font;
//import org.springframework.stereotype.Service;
//
//import java.io.ByteArrayOutputStream;
//import java.io.InputStream;
//import java.util.List;
//import java.util.Map;
//
//@Service
//public class PdfService {
//
//    // ✅ Extract text from PDF
//    public String extractText(InputStream inputStream) {
//        try (PDDocument document = PDDocument.load(inputStream)) {
//            PDFTextStripper pdfStripper = new PDFTextStripper();
//            return pdfStripper.getText(document);
//        } catch (Exception e) {
//            e.printStackTrace();
//            return "";
//        }
//    }
//
//    // ✅ Generate ATS Report PDF
//    public byte[] generateReport(Map<String, Object> data) {
//
//        try (PDDocument document = new PDDocument()) {
//
//            PDPage page = new PDPage();
//            document.addPage(page);
//
//            PDPageContentStream content = new PDPageContentStream(document, page);
//
//            content.beginText();
//            content.setLeading(16f);
//            content.newLineAtOffset(50, 750);
//
//            // Title
//            content.setFont(PDType1Font.HELVETICA_BOLD, 18);
//            content.showText("ATS Resume Report");
//            content.newLine();
//            content.newLine();
//
//            content.setFont(PDType1Font.HELVETICA, 12);
//
//            // Score
//            content.showText("Score: " + data.getOrDefault("score", "0"));
//            content.newLine();
//            content.newLine();
//
//            // Matched Keywords
//            content.showText("Matched Keywords:");
//            content.newLine();
//
//            List<String> matched = (List<String>) data.get("matchedKeywords");
//            if (matched != null) {
//                for (String m : matched) {
//                    content.showText("- " + m);
//                    content.newLine();
//                }
//            }
//
//            content.newLine();
//
//            // Missing Keywords
//            content.showText("Missing Keywords:");
//            content.newLine();
//
//            List<String> missing = (List<String>) data.get("missingKeywords");
//            if (missing != null) {
//                for (String m : missing) {
//                    content.showText("- " + m);
//                    content.newLine();
//                }
//            }
//
//            content.newLine();
//
//            // Suggestion
//            content.showText("Suggestion: " + data.getOrDefault("suggestion", "Improve missing skills"));
//
//            content.endText();
//            content.close();
//
//            ByteArrayOutputStream out = new ByteArrayOutputStream();
//            document.save(out);
//
//            return out.toByteArray();
//
//        } catch (Exception e) {
//            e.printStackTrace();
//            return new byte[0]; // ❗ IMPORTANT: never return null
//        }
//    }
//}
//
//




//package com.ai.resume_builder.service;
//
//import org.apache.pdfbox.pdmodel.PDDocument;
//import org.apache.pdfbox.text.PDFTextStripper;
//import org.apache.pdfbox.pdmodel.*;
//        import org.apache.pdfbox.pdmodel.font.PDType1Font;
//import org.springframework.stereotype.Service;
//
//import java.io.ByteArrayOutputStream;
//import java.io.InputStream;
//import java.util.List;
//import java.util.Map;
//
//@Service
//public class PdfService {
//
//    // ✅ Extract text from PDF
//    public String extractText(InputStream inputStream) {
//        try (PDDocument document = PDDocument.load(inputStream)) {
//            PDFTextStripper pdfStripper = new PDFTextStripper();
//            return pdfStripper.getText(document);
//        } catch (Exception e) {
//            e.printStackTrace();
//            return "";
//        }
//    }
//
//    // ✅ Generate ATS Report PDF (FINAL SAFE)
//    public byte[] generateReport(Map<String, Object> data) {
//
//        try (PDDocument document = new PDDocument()) {
//
//            PDPage page = new PDPage();
//            document.addPage(page);
//
//            PDPageContentStream content = new PDPageContentStream(document, page);
//
//            content.beginText();
//            content.setLeading(16f);
//            content.newLineAtOffset(50, 750);
//
//            // Title
//            content.setFont(PDType1Font.HELVETICA_BOLD, 18);
//            content.showText("ATS Resume Report");
//            content.newLine();
//            content.newLine();
//
//            content.setFont(PDType1Font.HELVETICA, 12);
//
//
//            // Score
//            content.showText("Score: " + data.getOrDefault("score", "0"));
//            content.newLine();
//            content.newLine();
//
//            // Matched Keywords
//            content.showText("Matched Keywords:");
//            content.newLine();
//
//            List<String> matched = (List<String>) data.get("matchedKeywords");
//
//            if (matched != null && !matched.isEmpty()) {
//                for (String m : matched) {
//                    content.showText("- " + m);
//                    content.newLine();
//                }
//            } else {
//                content.showText("- No matched keywords");
//                content.newLine();
//            }
//
//            content.newLine();
//
//            // Missing Keywords
//            content.showText("Missing Keywords:");
//            content.newLine();
//
//            List<String> missing = (List<String>) data.get("missingKeywords");
//
//            if (missing != null && !missing.isEmpty()) {
//                for (String m : missing) {
//                    content.showText("- " + m);
//                    content.newLine();
//                }
//            } else {
//                content.showText("- No missing keywords");
//                content.newLine();
//            }
//
//            content.newLine();
//
//            // Suggestion
//          content.showText("Suggestion: " + data.getOrDefault("suggestion", "Improve missing skills"));
//
//            content.endText();
//           content.close();
//
//            ByteArrayOutputStream out = new ByteArrayOutputStream();
//            document.save(out);
//
//            return out.toByteArray();
//
//        } catch (Exception e) {
//            e.printStackTrace();
//            return new byte[0]; // ❗ NEVER return null
//        }
//    }
//}
//
//


package com.ai.resume_builder.service;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
import org.apache.pdfbox.pdmodel.*;
        import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.List;
import java.util.Map;

@Service
public class PdfService {

    // ✅ Extract text from PDF
    public String extractText(InputStream inputStream) {
        try (PDDocument document = PDDocument.load(inputStream)) {
            PDFTextStripper pdfStripper = new PDFTextStripper();
            return pdfStripper.getText(document);
        } catch (Exception e) {
            e.printStackTrace();
            return "";
        }
    }

    // ✅ SAFE TEXT METHOD (VERY IMPORTANT)
    private String safeText(Object obj) {
        if (obj == null) return "";
        String text = String.valueOf(obj);

        // Remove unsupported characters
        text = text.replaceAll("[^\\x00-\\x7F]", "");

        // Limit length (PDFBox crash avoid)
        if (text.length() > 80) {
            text = text.substring(0, 80);
        }

        return text;
    }

    // ✅ Generate ATS Report PDF (FINAL SAFE)
    public byte[] generateReport(Map<String, Object> data) {

        try (PDDocument document = new PDDocument()) {

            PDPage page = new PDPage();
            document.addPage(page);

            PDPageContentStream content = new PDPageContentStream(document, page);

            content.beginText();
            content.setLeading(16f);
            content.newLineAtOffset(50, 750);

            // Title
            content.setFont(PDType1Font.HELVETICA_BOLD, 18);
            content.showText("ATS Resume Report");
            content.newLine();
            content.newLine();

            content.setFont(PDType1Font.HELVETICA, 12);

            // Score
            content.showText("Score: " + safeText(data.get("score")));
            content.newLine();
            content.newLine();

            // Matched Keywords
            content.showText("Matched Keywords:");
            content.newLine();

            List<String> matched = (List<String>) data.get("matchedKeywords");

            if (matched != null && !matched.isEmpty()) {
                for (String m : matched) {
                    content.showText("- " + safeText(m));
                    content.newLine();
                }
            } else {
                content.showText("- No matched keywords");
                content.newLine();
            }

            content.newLine();

            // Missing Keywords
            content.showText("Missing Keywords:");
            content.newLine();

            List<String> missing = (List<String>) data.get("missingKeywords");

            if (missing != null && !missing.isEmpty()) {
                for (String m : missing) {
                    content.showText("- " + safeText(m));
                    content.newLine();
                }
            } else {
                content.showText("- No missing keywords");
                content.newLine();
            }

            content.newLine();

            // Suggestion (SAFE)
            content.showText("Suggestion: " + safeText(data.get("suggestion")));

            content.endText();
            content.close();

            ByteArrayOutputStream out = new ByteArrayOutputStream();
            document.save(out);

            return out.toByteArray();

        } catch (Exception e) {
            e.printStackTrace();
            return new byte[0]; // ❗ NEVER null
        }
    }
}