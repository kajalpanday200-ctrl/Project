package com.ai.resume_builder.dto;

import lombok.Data;
import java.util.List;

@Data
public class AtsResponse {
    private double score;
    private List<String> matchedSkills;
    private List<String> missingSkills;
}