//package com.ai.resume_builder.dto;
//
//import lombok.Getter;
//import lombok.Setter;
//
//@Setter
//@Getter
//public class AtsRequest {
//
//    private String jobDescription;
//    private String resumeText;
//
//    public AtsRequest() {}
//
//}



package com.ai.resume_builder.dto;

public class AtsRequest {

    private String jobDescription;
    private String resumeText;

    public String getJobDescription() {
        return jobDescription;
    }

    public void setJobDescription(String jobDescription) {
        this.jobDescription = jobDescription;
    }

    public String getResumeText() {
        return resumeText;
    }

    public void setResumeText(String resumeText) {
        this.resumeText = resumeText;
    }
}