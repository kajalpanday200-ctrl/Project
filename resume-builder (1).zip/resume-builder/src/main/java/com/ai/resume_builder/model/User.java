//package com.ai.resume_builder.model;//package com.ai.resume_builder.model;
////
////import lombok.Data;
////import org.springframework.data.annotation.Id;
////import org.springframework.data.mongodb.core.mapping.Document;
////
////@Data
////@Document(collection = "users")
////public class UserData {
////
////    @Id
////    private String id;
////
////    private String email;
////    private String password;
////
////    public String getName() {
////        return email;
////    }
////}
//
//
//import org.springframework.data.annotation.Id;
//import org.springframework.data.mongodb.core.mapping.Document;
//
////package com.ai.resume_builder.model;
////
////import lombok.Data;
////import org.springframework.data.annotation.Id;
////import org.springframework.data.mongodb.core.mapping.Document;
////
////@Data
////@Document(collection = "users")
////public class User {
////
////    @Id
////    private String id;
////
////    private String email;
////    private String password;
////
////
//    @Document(collection = "users")
//    public class User {
//
//        @Id
//        private String id;
//
//    private String password;
//
//    public User(String username, String email) {
//    }
//
//    public Object getPassword() {
//        return null;
//    }
//
//    public String getEmail() {
//        return null;
//    }
//
//    // getters setters
//    }



package com.ai.resume_builder.model;

import lombok.Getter;
import lombok.Setter;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Setter
@Getter
@Document(collection = "users")
public class User {

    @Id
    private String id;

    private String username;
    // 🔥 IMPORTANT
    // 🔥 IMPORTANT
    private String email;     // 🔥 MUST ADD
    private String password;

    // ✅ GETTERS & SETTERS

}