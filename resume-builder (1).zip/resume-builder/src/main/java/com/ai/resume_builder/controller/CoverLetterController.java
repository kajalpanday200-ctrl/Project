package com.ai.resume_builder.controller;


import com.ai.resume_builder.service.CoverLetterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.Map;


@RestController
@RequestMapping("/api/cover")
public class CoverLetterController {

    @Autowired
    private CoverLetterService service;

    @PostMapping("/upload")
    public Map<String, Object> upload(@RequestParam("file") MultipartFile file) {
        return service.extractResume(file);
    }


}