package com.ai.resume_builder.controller;

import com.ai.resume_builder.model.User;
import com.ai.resume_builder.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/auth")
@CrossOrigin(origins = "*")
public class AuthController {

    @Autowired
    private UserRepository repo;

    // ================= SIGNUP ============== }
    
    @PostMapping("/signup")
    public ResponseEntity<String> signup(@RequestBody User user) {

        String emailRegex = "^[A-Za-z0-9+_.-]+@(.+)$";

        // ================= VALIDATION =================
        if (user.getUsername() == null || user.getUsername().trim().isEmpty()
                || user.getEmail() == null || user.getEmail().trim().isEmpty()
                || user.getPassword() == null || user.getPassword().trim().isEmpty()) {
            return ResponseEntity.badRequest().body("All fields are required ❌");
        }

        // ================= NAME VALIDATION =================
        if (!user.getUsername().matches("^[a-zA-Z ]{3,30}$")) {
            return ResponseEntity.badRequest().body("Name must be only letters (3-30 chars) ❌");
        }

        // ================= EMAIL VALIDATION =================
        if (!user.getEmail().matches(emailRegex)) {
            return ResponseEntity.badRequest().body("Invalid email format ❌");
        }

        // ================= GMAIL CHECK (YOUR REQUIREMENT) =================
        if (!user.getEmail().endsWith("@gmail.com")) {
            return ResponseEntity.badRequest().body("Only Gmail accounts allowed ❌");
        }

        // ================= PASSWORD VALIDATION =================
        if (user.getPassword().length() < 6) {
            return ResponseEntity.badRequest().body("Password must be at least 6 characters ❌");
        }

        // ================= DUPLICATE CHECK =================
        if (repo.findByEmail(user.getEmail()).isPresent()) {
            return ResponseEntity.badRequest().body("User already exists ❌");
        }

        repo.save(user);
        return ResponseEntity.ok("Account created successfully ✅");
    }


    // ================= LOGIN =================
    @PostMapping("/login")
    public ResponseEntity<String> login(@RequestBody User user) {

        // 🔥 VALIDATION (IMPORTANT)
        if (user.getEmail() == null || user.getEmail().trim().isEmpty()
                || user.getPassword() == null || user.getPassword().trim().isEmpty()) {

            return ResponseEntity
                    .badRequest()
                    .body("Email and Password required ❌");
        }

        User u = repo.findByEmail(user.getEmail())
                .orElse(null);

        if (u == null) {
            return ResponseEntity
                    .badRequest()
                    .body("User not found ❌");
        }

        if (!u.getPassword().equals(user.getPassword())) {
            return ResponseEntity
                    .badRequest()
                    .body("Invalid password ❌");
        }

        // 🔥 SIMPLE TOKEN (future JWT upgrade)
        String token = "LOGIN_SUCCESS_" + u.getEmail();

        return ResponseEntity.ok(token);
    }
}