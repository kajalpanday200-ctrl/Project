package com.ai.resume_builder.controller;

import com.ai.resume_builder.model.Job;
import com.ai.resume_builder.repository.JobRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")   // ✅ good practice
@CrossOrigin(origins = "*")
public class JobController {

    @Autowired
    private JobRepository repo;

    @GetMapping("/jobs")
    public List<Job> all(){
        return repo.findAll();
    }

    @PostMapping("/jobs")
    public Job add(@RequestBody Job job){
        return repo.save(job);
    }
}