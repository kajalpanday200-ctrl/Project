package com.ai.resume_builder.controller;

import com.ai.resume_builder.dto.AtsRequest;
import com.ai.resume_builder.dto.SkillGapResponse;
import com.ai.resume_builder.service.SkillGapService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/skill-gap")
public class SkillGapController {

    @Autowired
    private SkillGapService skillGapService;

    @PostMapping("/analyze")
    public SkillGapResponse analyzeGap(@RequestBody AtsRequest request) {
        return skillGapService.analyzeGap(request);
    }
}


