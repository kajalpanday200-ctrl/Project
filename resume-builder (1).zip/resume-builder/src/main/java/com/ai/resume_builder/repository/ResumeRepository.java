package com.ai.resume_builder.repository;

import com.ai.resume_builder.model.Resume;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface ResumeRepository extends MongoRepository<Resume, String> {
}


