package com.ai.resume_builder.service;
import com.ai.resume_builder.model.Job;
import com.ai.resume_builder.repository.JobRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class JobService {

    @Autowired
    private
    JobRepository repo;

    public <Resume> List<Job> matchJobs(Resume r){

        return repo.findAll().stream()
                .filter(j -> r.getClass().isArray())
                .collect(Collectors.toList());
    }
}