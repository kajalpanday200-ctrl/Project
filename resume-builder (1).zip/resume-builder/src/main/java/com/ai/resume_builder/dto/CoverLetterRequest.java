package com.ai.resume_builder.dto;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class CoverLetterRequest {


    // getters & setters
    private String name;
    private String email;
    private String jobRole;
    private String company;
    private String skills;
    private String experience;
    private String prompt; // optional AI input

}