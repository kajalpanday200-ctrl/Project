package com.ai.resume_builder.dto;

import lombok.*;
import org.springframework.web.multipart.MultipartFile;

@Data
public class ResumeRequest {
    private MultipartFile file;
    private String jobDescription;
    private String analysisType;
}