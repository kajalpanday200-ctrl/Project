package com.ai.resume_builder.dto;

import java.util.List;

public class ResumeResponse {




        private String name;
        private String email;
        private String education;
        private List<String> skills;
        private List<String> projects;
        private String experience;
        private String certificates;
        private String github;
        private String linkedin;

        // getters setters
    }

