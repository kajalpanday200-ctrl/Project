//package com.ai.resume_builder.repository;
//
//
//import com.ai.resume_builder.model.Job;
//import org.springframework.data.mongodb.repository.MongoRepository;
//
//public interface JobRepository extends MongoRepository<Job,String> {
//}


package com.ai.resume_builder.repository;

import com.ai.resume_builder.model.Job;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface JobRepository extends MongoRepository<Job, String> {
}