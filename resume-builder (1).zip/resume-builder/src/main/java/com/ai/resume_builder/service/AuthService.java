package com.ai.resume_builder.service;

import com.ai.resume_builder.model.User;
import com.ai.resume_builder.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class AuthService {

    @Autowired
    private UserRepository repo;

    // ================= SIGNUP =================
    public String signup(User user) {

        // ❌ validation
        if (user.getUsername() == null || user.getUsername().trim().isEmpty()
                || user.getEmail() == null || user.getEmail().trim().isEmpty()
                || user.getPassword() == null || user.getPassword().trim().isEmpty()) {
            return "All fields are required ❌";
        }

        // ❌ already exists
        if (repo.findByEmail(user.getEmail()).isPresent()) {
            return "User already exists ❌";
        }

        repo.save(user);
        return "Account created successfully ✅";
    }

    // ================= LOGIN =================
    public String login(User user) {

        // ❌ validation
        if (user.getEmail() == null || user.getEmail().trim().isEmpty()
                || user.getPassword() == null || user.getPassword().trim().isEmpty()) {
            return "Email and Password required ❌";
        }

        Optional<User> dbUser = repo.findByEmail(user.getEmail());

        if (dbUser.isEmpty()) {
            return "User not found ❌";
        }

        User u = dbUser.get();

        if (!u.getPassword().equals(user.getPassword())) {
            return "Invalid password ❌";
        }

        // 🔥 simple token (JWT later upgrade)
        return "LOGIN_SUCCESS_" + u.getEmail();
    }
}