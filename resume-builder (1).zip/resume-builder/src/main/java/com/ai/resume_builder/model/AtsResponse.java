//package com.ai.resume_builder.model;
//
//import lombok.Getter;
//import lombok.Setter;
//
//import java.util.List;
//
//@Setter
//@Getter
//public class AtsResponse {
//
//    private int score;
//    private List<String> matchedSkills;
//    private List<String> missingSkills;
//
//    public AtsResponse() {}
//
//}


//package com.ai.resume_builder.model;
//
//import lombok.Getter;
//import lombok.Setter;
//
//import java.util.ArrayList;
//
//@Setter
//@Getter
//public class AtsResponse {
//
//    private int score;
//
//    public void setMatchedSkills(ArrayList<String> strings) {
//        this.score = strings.size();
//    }
//
//    public void setMissingSkills(ArrayList<String> strings) {
//        this.score = strings.size();
//    }
//}






package com.ai.resume_builder.model;

import java.util.List;

public class AtsResponse {

    private int score;
    private List<String> matchedKeywords;
    private List<String> missingKeywords;
    private List<String> suggestions;

    public AtsResponse(int score, List<String> matchedKeywords,
                       List<String> missingKeywords, List<String> suggestions) {
        this.score = score;
        this.matchedKeywords = matchedKeywords;
        this.missingKeywords = missingKeywords;
        this.suggestions = suggestions;
    }

    public int getScore() { return score; }
    public List<String> getMatchedKeywords() { return matchedKeywords; }
    public List<String> getMissingKeywords() { return missingKeywords; }
    public List<String> getSuggestions() { return suggestions; }
}